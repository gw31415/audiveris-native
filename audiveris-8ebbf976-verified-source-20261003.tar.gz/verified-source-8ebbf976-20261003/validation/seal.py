#!/usr/bin/env python3
"""Seal only a successful fixed-source checkpoint, without changing that source."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,tarfile,time
ROOT=Path('/workspace/audiveris-restart');OUT=Path(__file__).resolve().parent;RECEIPTS=OUT.parent
BASE='18639b22cc33c1194d4be1ca4a661ce7bb5c1a90';HEAD='8ebbf976f568f91077d32221d52366d71559ab75'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
state=json.loads((OUT/'state.json').read_text());assert state['status']=='passed', 'validation is not complete/passing'
assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain'), 'fixed source changed'
for stage in ['debug','release']:
    step=next(v for v in state['steps'] if v['name']==stage)
    assert step['exit_code']==0 and step['tests']['totals']['passed']>0 and step['tests']['totals']['failed']==0
binary=state['release_binary'];assert sha(Path(binary['path']))==binary['sha256']
plan=json.loads((OUT/'next-stage-plan.json').read_text());plan['status']='ready to propose after full fixed-source validation passed; no implementation started';(OUT/'next-stage-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
start=time.monotonic();package=RECEIPTS/'full-workspace-cumulative-8ebbf976-20261003';package.mkdir(exist_ok=False)
bundle=package/'audiveris-v17-to-8ebbf976.bundle';subprocess.run(['git','bundle','create',str(bundle),BASE+'..HEAD'],cwd=ROOT,check=True)
verified=subprocess.run(['git','bundle','verify',str(bundle)],cwd=ROOT,capture_output=True,text=True,check=True);(package/'bundle-verify.log').write_text(verified.stdout+verified.stderr)
with (package/'audiveris-v17-to-8ebbf976.patch').open('wb') as f:subprocess.run(['git','format-patch','--stdout',BASE+'..HEAD'],cwd=ROOT,stdout=f,check=True)
evidence=package/'validation';shutil.copytree(OUT,evidence)
(package/'RESTORE.txt').write_text('Full workspace verified source checkpoint. Requires recovered v17 base '+BASE+'.\nSource commit is unchanged: '+HEAD+'. No implementation was added in this validation task.\nVerify bundle in a repository containing v17: git bundle verify audiveris-v17-to-8ebbf976.bundle\nFetch the bundle HEAD into a NEW isolated branch; do not overwrite active work.\nDebug/release counts, commands, timings and logs are in validation/state.json and corresponding logs.\nA fresh release binary was built and hashed; this compact source/evidence delta does not contain that executable or a Rust toolchain.\nThe extension-loop plan is future work, not an implemented/full-BEAMS claim.\n')
manifest={'base_required':BASE,'source_commit':HEAD,'source_tree':state['source_tree'],'new_source_commit_this_task':False,'source_clean':True,'cumulative_commits':int(git('rev-list','--count',BASE+'..HEAD')),'tracked_files':len(git('ls-files').splitlines()),'validation':state,'release_binary_included':False,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{str(p.relative_to(package)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in package.rglob('*') if p.is_file()}}
(package/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=RECEIPTS/'audiveris-full-workspace-8ebbf976-20261003.tar.gz'
with tarfile.open(archive,'w:gz') as tf:tf.add(package,arcname=package.name)
receipt={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'source_commit':HEAD,'base':BASE,'tracked_files':manifest['tracked_files'],'cumulative_commits':manifest['cumulative_commits'],'source_tree':state['source_tree'],'binary':binary,'artifact_command_seconds':time.monotonic()-start}
(RECEIPTS/'full-workspace-artifact.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))

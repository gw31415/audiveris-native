#!/usr/bin/env python3
"""Compact self-contained transfer replacing the delta-only packaging plan."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,tarfile,time
ROOT=Path('/workspace/audiveris-restart');OUT=Path(__file__).resolve().parent;R=OUT.parent
HEAD='8ebbf976f568f91077d32221d52366d71559ab75'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
state=json.loads((OUT/'state.json').read_text());assert state['status']=='passed'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
source=json.loads((OUT/'compact-source-archive.json').read_text());assert sha(Path(source['path']))==source['sha256']
assert sha(Path(state['release_binary']['path']))==state['release_binary']['sha256']
plan=json.loads((OUT/'next-stage-plan.json').read_text());plan['status']='planned future work only; full validation passed; STOP after durable save for model handoff';(OUT/'next-stage-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
start=time.monotonic();package=R/'verified-source-8ebbf976-20261003';package.mkdir(exist_ok=False)
shutil.copyfile(source['path'],package/'source.tar.xz');shutil.copytree(OUT,package/'validation')
handoff={'source_commit':HEAD,'source_tree':state['source_tree'],'tracked_files':4299,'source_snapshot':source,'source_archive_needs_base':False,'git_history_included':False,'release_binary_included':False,'release_binary':state['release_binary'],'validation':state,'stop_after_save':True,'requested_next_model':'gpt-6.1-sol','requested_next_reasoning':'high','requested_next_service_tier':'fast','model_change_applied_to_this_task':False,'library_identity':'libfile_e87856bdb5dc81918f503bb15932ded2','prior_cumulative_delta_version':5,'git_history_fallback':{'repository':'https://github.com/gw31415/audiveris-native','main_commit':'89f3eac257d0fb1ec735b95802d8c084a5f34ff5','bundle_file':'audiveris-linux-beam-candidates-handoff-history.bundle','bundle_bytes':13504957,'bundle_sha256':'e1bae694a4dc194ee58269341919219596060749428ab2b4f45ce9ef703cc059','base_ref':'cloud/native-headers','base_commit':'18639b22cc33c1194d4be1ca4a661ce7bb5c1a90','base_label':'older recoverable v17','current_branch':'restart/20261003-candidates','current_head':HEAD},'consumer_notes':['Unpack outer archive, then source.tar.xz. Source snapshot builds without retrieving the v17 Git bundle. It contains no .git metadata, so do not assert an initialized repository has the original commit identity.','Use HANDOFF.json and validation/state.json for exact verified source identity and results. No implementation was changed during this checkpoint.','Rust 1.98.1 and normal Cargo dependencies/cache are required; toolchain/build caches and original Java distribution are not transferred. Java is development-only and not a native runtime dependency.','No whole extension loop or full OMR is implemented. Next-stage plan is not executed.','7cdd was not retrieved or compared. Preserve older active workers/files; their stopped status was not verified.']}
(package/'HANDOFF.json').write_text(json.dumps(handoff,indent=2)+'\n')
archive=R/'audiveris-8ebbf976-verified-source-20261003.tar.gz'
with tarfile.open(archive,'w:gz') as tf:tf.add(package,arcname=package.name)
receipt={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'source_commit':HEAD,'source_tree':state['source_tree'],'source_archive':source,'binary':state['release_binary'],'artifact_command_seconds':time.monotonic()-start,'source_implementation_changed':False,'history_or_build_cache_included':False}
(R/'full-workspace-source-artifact.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))

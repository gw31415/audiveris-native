#!/usr/bin/env python3
"""Validation-only runner; all output is outside the fixed source repository."""
import datetime,hashlib,json,os,re,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/audiveris-restart')
OUT=Path(__file__).resolve().parent
HEAD='8ebbf976f568f91077d32221d52366d71559ab75'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def save():
    temp=OUT/'state.tmp';temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(OUT/'state.json')
def summarize(path):
    rows=[];target='unknown'
    for line in path.read_text(errors='replace').splitlines():
        if 'Running ' in line:target=line.strip()
        elif 'Doc-tests ' in line:target=line.strip()
        m=re.search(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([\d.]+)s',line)
        if m:rows.append({'target':target,'status':m[1],**dict(zip(['passed','failed','ignored','measured','filtered_out'],map(int,m.group(2,3,4,5,6)))),'test_body_seconds':float(m[7])})
    return {'targets':rows,'totals':{k:sum(r[k] for r in rows) for k in ['passed','failed','ignored','measured','filtered_out']},'summed_test_body_seconds':sum(r['test_body_seconds'] for r in rows)}
assert git('rev-parse','HEAD')==HEAD
assert not git('status','--porcelain'), 'source must start clean'
env=os.environ.copy();env.update(RUSTUP_HOME='/workspace/audiveris-toolchain/rustup',CARGO_HOME='/workspace/audiveris-toolchain/cargo',CARGO_TARGET_DIR='/workspace/audiveris-toolchain/target');env['PATH']='/workspace/audiveris-toolchain/cargo/bin:'+env['PATH']
state={'source_commit':HEAD,'source_tree':git('rev-parse','HEAD^{tree}'),'source_root':str(ROOT),'started_utc':utc(),'runner_pid':os.getpid(),'status':'running','steps':[],'environment':{k:env[k] for k in ['RUSTUP_HOME','CARGO_HOME','CARGO_TARGET_DIR']},'scope':'No source edits, no new kernel; fixed-source full workspace checkpoint'}
save();start=time.monotonic()
commands=[('fmt',['cargo','+1.98.1','fmt','--all','--','--check']),('clippy',['cargo','+1.98.1','clippy','--workspace','--locked','--offline','--all-targets','-j','2','--','-D','warnings']),('debug',['cargo','+1.98.1','test','--workspace','--locked','--offline','-j','2']),('release',['cargo','+1.98.1','test','--workspace','--release','--locked','--offline','-j','2']),('release-build',['cargo','+1.98.1','build','--release','--locked','--offline','-j','2'])]
try:
    for name,command in commands:
        assert git('rev-parse','HEAD')==HEAD, 'source commit changed during validation'
        assert not git('diff','--name-only','HEAD'), 'tracked source changed during validation'
        log=OUT/(name+'.log');step={'name':name,'command':command,'started_utc':utc(),'status':'running','log':str(log)};state['steps'].append(step);state['current_stage']=name;save();t=time.monotonic()
        with log.open('w') as output:
            process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
            step['pid']=process.pid;save();code=process.wait()
        step.update(exit_code=code,seconds=time.monotonic()-t,finished_utc=utc(),status='passed' if code==0 else 'failed')
        if name in ['debug','release']:step['tests']=summarize(log)
        save();print(name,step['status'],round(step['seconds'],3),flush=True)
        if code:raise RuntimeError(name+' failed; no source repair attempted in this fixed-source task')
    binary=Path(env['CARGO_TARGET_DIR'])/'release/audiveris-native'
    state['release_binary']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
    state['ending_commit']=git('rev-parse','HEAD');state['ending_status_porcelain']=git('status','--porcelain');assert state['ending_commit']==HEAD and not state['ending_status_porcelain']
    state['status']='passed'
except Exception as error:
    state['status']='failed';state['error']=str(error)
finally:
    state['finished_utc']=utc();state['seconds']=time.monotonic()-start;save();print(json.dumps({'status':state['status'],'seconds':state['seconds']}),flush=True)

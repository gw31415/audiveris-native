Audiveris native limited Linux CLI
Source: a2bf13ca8da7afe0b9e41da491190558898f4b34
License: AGPL-3.0-or-later; LICENSE included. Corresponding source is recovered
from private gw31415/audiveris-native checkpoint sol-musicxml-half-rest-links-20261005
with its RESTORE.py and full SOURCE-SHA256.json. No original Java runtime required.

Linux x86_64 ELF64, dynamic libgcc_s/libm/libc, symbols require GLIBC_2.35.
Tested only in the existing Linux Cloud environment, not every Linux distribution.
Binary SHA256: 70938e9caf851b10b6cef4962bcb398a8ef9f3b5c14c9815d722b2d4275a82af
Build: CARGO_INCREMENTAL=0 cargo build --release --offline --locked --bin audiveris-musicxml --jobs 1
Full workspace tests: 544 passed on this source; fmt/clippy passed.

Extract, then run from this directory:
  sha256sum -c SHA256SUMS
  mkdir out
  ./audiveris-musicxml --output-dir out --part-name Flute examples/quarter-rest.png examples/half-two-measures.png examples/quarter-half-break.png examples/half-rest-y241.png
  ./audiveris-musicxml examples/half-rest-y239.png half-rest.musicxml half-rest.report.json
Outputs must be new; output directory must exist. A later batch refusal keeps
earlier successful pairs. Part name is metadata, not instrument recognition.

限定対応: 不透明PNG/PGM、400万画素以下、Bravura/interline11、傾き0、通常五線、
ト音記号/C major/明示4拍子、単一非移調part/単声、完全小節の四分・二分音符と休符。
3独立合成譜面24イベントと、同じ二分休符譜面の2位置条件10イベントを区別して検証。
原版との比較境界はXML保存HEADS以後。native CLI自身は画像から認識し、原版XMLは使わない。
二分休符のbeam処理はstump/seedなし・到達可能headなしの限定条件。
弱い休符を除去して小節が不足すれば拒否する。音符や休符を補造しない。
未対応: 任意実スキャン/写真/PDF、別フォント/サイズ/斜め/特殊staff、全24形ページ、
実際のbeam/flag八分音符、臨時記号/付点/tie/slur/tuplet、多声/弱起/複数staff/移調。
限定cleaner/epilog確認は完全STEMS/LINKS移植を意味しない。全体完了フラグはfalse。
This is a bounded prototype CLI, not practical completion for arbitrary scores.

// Copyright © Audiveris 2026. SPDX-License-Identifier: AGPL-3.0-or-later
// Native GlyphIndex content identity, SpotsBuilder dispatch and SystemInfo group
// lifecycle at 9e1e55cd2746037d059345881c53e6a6754bffbd.
// Native phase identities are not original Java numeric IDs. Registered values
// remain strongly owned through the native BEAMS phase; no JVM GC is simulated.
use crate::{MAX_PIXELS, curves::Curve};
use audiveris_staff_removal::{GlyphPixels, Orientation, Run};
use serde::Serialize;
use serde_json::{Value, json};
use std::collections::{BTreeMap, BTreeSet};

pub const MAX_REGISTERED_GLYPHS: usize = 100_000;
pub const MAX_REGISTERED_RUNS: usize = 1_000_000;
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Serialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum Group {
    BeamSpot,
    BlackHeadSpot,
    BlackStackSpot,
    VerticalSeed,
}
#[derive(Clone, Debug)]
pub struct Entry {
    pub glyph: GlyphPixels,
    pub groups: BTreeSet<Group>,
}
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
struct Key {
    left: i32,
    top: i32,
    width: usize,
    height: usize,
    vertical: bool,
    runs: Vec<[usize; 3]>,
}
fn key(g: &GlyphPixels) -> Result<Key, String> {
    if g.left.unsigned_abs() as usize > MAX_PIXELS
        || g.top.unsigned_abs() as usize > MAX_PIXELS
        || g.width == 0
        || g.height == 0
        || g.width.checked_mul(g.height).is_none_or(|n| n > MAX_PIXELS)
        || g.runs.is_empty()
        || g.runs.len() > MAX_REGISTERED_RUNS
    {
        return Err("invalid_beam_registry_glyph".into());
    }
    let vertical = g.orientation == Orientation::Vertical;
    let (positions, length) = if vertical {
        (g.width, g.height)
    } else {
        (g.height, g.width)
    };
    let mut last = None;
    for r in &g.runs {
        let stop = r
            .start
            .checked_add(r.length)
            .filter(|v| *v <= length)
            .ok_or("invalid_beam_registry_run")?;
        if r.length == 0
            || r.position >= positions
            || last.is_some_and(|(p, end)| r.position < p || (r.position == p && r.start <= end))
        {
            return Err("invalid_beam_registry_run_order".into());
        }
        last = Some((r.position, stop));
    }
    Ok(Key {
        left: g.left,
        top: g.top,
        width: g.width,
        height: g.height,
        vertical,
        runs: g
            .runs
            .iter()
            .map(|r| [r.position, r.start, r.length])
            .collect(),
    })
}
/// Original pixel barycenter, rounded by java.awt.Point assignment with Math.rint.
pub fn centroid(g: &GlyphPixels) -> Result<[i32; 2], String> {
    key(g)?;
    let (mut weight, mut sx, mut sy) = (0i64, 0i64, 0i64);
    for r in &g.runs {
        let n = r.length as i64;
        let along = n * (2 * r.start as i64 + n - 1) / 2;
        let across = n * r.position as i64;
        weight += n;
        if g.orientation == Orientation::Vertical {
            sx += across;
            sy += along;
        } else {
            sx += along;
            sy += across;
        }
    }
    Ok([
        (g.left as f64 + sx as f64 / weight as f64).round_ties_even() as i32,
        (g.top as f64 + sy as f64 / weight as f64).round_ties_even() as i32,
    ])
}
#[derive(Default, Debug)]
pub struct Registry {
    entries: Vec<Entry>,
    keys: BTreeMap<Key, usize>,
    runs: usize,
}
impl Registry {
    pub fn register(&mut self, g: &GlyphPixels) -> Result<usize, String> {
        let key = key(g)?;
        if let Some(id) = self.keys.get(&key) {
            return Ok(*id);
        }
        if self.entries.len() >= MAX_REGISTERED_GLYPHS
            || self
                .runs
                .checked_add(g.runs.len())
                .is_none_or(|v| v > MAX_REGISTERED_RUNS)
        {
            return Err("unsupported_beam_registry_budget".into());
        }
        let id = self.entries.len() + 1;
        self.runs += g.runs.len();
        self.entries.push(Entry {
            glyph: g.clone(),
            groups: BTreeSet::new(),
        });
        self.keys.insert(key, id);
        Ok(id)
    }
    pub fn add_group(&mut self, id: usize, group: Group) -> Result<(), String> {
        self.entries
            .get_mut(id.checked_sub(1).ok_or("invalid_beam_glyph_id")?)
            .ok_or("invalid_beam_glyph_id")?
            .groups
            .insert(group);
        Ok(())
    }
    pub fn get(&self, id: usize) -> Result<&Entry, String> {
        self.entries
            .get(id.checked_sub(1).ok_or("invalid_beam_glyph_id")?)
            .ok_or("invalid_beam_glyph_id".into())
    }
    pub fn len(&self) -> usize {
        self.entries.len()
    }
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
    pub fn snapshot(&self) -> Value {
        json!(
            self.entries
                .iter()
                .enumerate()
                .map(|(i, e)| json!({"id":i+1,"glyph":glyph_json(&e.glyph),"groups":e.groups}))
                .collect::<Vec<_>>()
        )
    }
}
pub fn glyph_json(g: &GlyphPixels) -> Value {
    json!({"bounds":[g.left as i64,g.top as i64,g.width as i64,g.height as i64],"orientation":if g.orientation==Orientation::Vertical{"VERTICAL"}else{"HORIZONTAL"},"runs":g.runs.iter().map(|r|[r.position,r.start,r.length]).collect::<Vec<_>>()})
}
/// Decode an existing native canonical glyph, retaining run orientation and
/// bounds exactly. No theoretical/inter bounds are substituted for glyph pixels.
pub fn glyph_from_json(v: &Value) -> Result<GlyphPixels, String> {
    let bounds = v["bounds"]
        .as_array()
        .filter(|v| v.len() == 4)
        .ok_or("invalid_beam_canonical_bounds")?;
    let left = integer(&bounds[0])?;
    let top = integer(&bounds[1])?;
    let width = integer(&bounds[2])?;
    let height = integer(&bounds[3])?;
    if width <= 0 || height <= 0 {
        return Err("invalid_beam_canonical_dimensions".into());
    }
    let orientation = match v["orientation"].as_str() {
        Some("VERTICAL") => Orientation::Vertical,
        Some("HORIZONTAL") => Orientation::Horizontal,
        _ => return Err("invalid_beam_canonical_orientation".into()),
    };
    let raw = v["runs"]
        .as_array()
        .filter(|v| !v.is_empty() && v.len() <= MAX_REGISTERED_RUNS)
        .ok_or("invalid_beam_canonical_runs")?;
    let mut runs = Vec::with_capacity(raw.len());
    for r in raw {
        let r = r
            .as_array()
            .filter(|r| r.len() == 3)
            .ok_or("invalid_beam_canonical_run")?;
        let mut n = [0usize; 3];
        for (i, v) in r.iter().enumerate() {
            n[i] = v
                .as_u64()
                .filter(|n| *n <= MAX_PIXELS as u64)
                .ok_or("invalid_beam_canonical_run_value")? as usize;
        }
        runs.push(Run {
            position: n[0],
            start: n[1],
            length: n[2],
        });
    }
    let glyph = GlyphPixels {
        left,
        top,
        width: width as usize,
        height: height as usize,
        orientation,
        runs,
    };
    key(&glyph)?;
    Ok(glyph)
}
fn number(v: &Value) -> Result<f64, String> {
    v.as_f64()
        .filter(|n| n.is_finite() && n.abs() <= MAX_PIXELS as f64)
        .ok_or("invalid_beam_dispatch_coordinate".into())
}
fn integer(v: &Value) -> Result<i32, String> {
    v.as_i64()
        .filter(|v| v.unsigned_abs() <= MAX_PIXELS as u64)
        .map(|v| v as i32)
        .ok_or("invalid_beam_dispatch_integer".into())
}
fn curve(row: &Value, budget: &mut usize) -> Result<Curve, String> {
    let raw = row["points"]
        .as_array()
        .filter(|p| (2..=4096).contains(&p.len()))
        .ok_or("invalid_beam_dispatch_curve")?;
    *budget += raw.len();
    if *budget > 65536 {
        return Err("unsupported_beam_dispatch_curve_budget".into());
    }
    let points = raw
        .iter()
        .map(|p| {
            let p = p
                .as_array()
                .filter(|p| p.len() == 2)
                .ok_or("invalid_beam_dispatch_point")?;
            Ok([number(&p[0])?, number(&p[1])?])
        })
        .collect::<Result<Vec<_>, String>>()?;
    Curve::interpolate(points).ok_or("invalid_beam_dispatch_curve".into())
}
fn system_area(
    width: usize,
    height: usize,
    north: Option<&Curve>,
    south: Option<&Curve>,
    margin: f64,
) -> Result<audiveris_area::Area, String> {
    fn boundary(width: usize, curve: Option<&Curve>, shift: f64, flat: f64) -> Vec<Vec<[f64; 2]>> {
        let Some(curve) = curve else {
            return vec![vec![[0., flat], [width as f64, flat]]];
        };
        let first = curve.points[0];
        let last = *curve.points.last().unwrap();
        let mut segments = vec![vec![[0., first[1] + shift], [first[0], first[1] + shift]]];
        segments.extend(
            curve
                .path_segments()
                .iter()
                .map(|s| s.iter().map(|p| [p[0], p[1] + shift]).collect::<Vec<_>>()),
        );
        segments.push(vec![
            [last[0], last[1] + shift],
            [width as f64, last[1] + shift],
        ]);
        segments
    }
    let mut segments = boundary(width, north, margin, 0.);
    segments.extend(
        boundary(width, south, -margin, height as f64)
            .into_iter()
            .rev()
            .map(|mut segment| {
                segment.reverse();
                segment
            }),
    );
    audiveris_area::Area::from_closed_segments(&segments)
}
pub const MAX_AREA_QUERY_WORK: usize = 100_000_000;
#[derive(Debug)]
pub struct SystemArea {
    pub id: u64,
    pub left: i32,
    pub right: i32,
    area: audiveris_area::Area,
}
#[derive(Debug)]
pub struct Geometry {
    pub systems: Vec<SystemArea>,
    width: usize,
    height: usize,
    query_work: usize,
}
impl Geometry {
    pub fn from_grid(
        width: usize,
        height: usize,
        grid: &Value,
        interline: usize,
    ) -> Result<Self, String> {
        if width == 0
            || height == 0
            || width.checked_mul(height).is_none_or(|n| n > MAX_PIXELS)
            || !(1..=128).contains(&interline)
        {
            return Err("invalid_beam_dispatch_dimensions".into());
        }
        let staffs = grid["staffs"]
            .as_array()
            .filter(|v| !v.is_empty() && v.len() <= 1024)
            .ok_or("invalid_beam_dispatch_staffs")?;
        let raw = grid["systems"]
            .as_array()
            .filter(|v| !v.is_empty() && v.len() <= 1024)
            .ok_or("invalid_beam_dispatch_systems")?;
        let mut curves = BTreeMap::new();
        let mut staff_systems = BTreeMap::new();
        let mut order = Vec::new();
        let mut budget = 0;
        for row in staffs {
            let id = row["id"].as_u64().ok_or("invalid_beam_dispatch_staff_id")?;
            let lines = row["lines"]
                .as_array()
                .filter(|v| v.len() == 5)
                .ok_or("unsupported_beam_dispatch_staff_lines")?;
            if curves
                .insert(
                    id,
                    (
                        curve(&lines[0], &mut budget)?,
                        curve(&lines[4], &mut budget)?,
                    ),
                )
                .is_some()
            {
                return Err("duplicate_beam_dispatch_staff".into());
            }
            staff_systems.insert(
                id,
                row["system_id"]
                    .as_u64()
                    .ok_or("invalid_beam_dispatch_staff_system")?,
            );
            order.push(id);
        }
        let margin = (0.9 * interline as f64).round_ties_even();
        let mut system_ids = BTreeSet::new();
        let mut members = Vec::new();
        let mut seen_members = BTreeSet::new();
        let mut systems = Vec::new();
        for (index, system) in raw.iter().enumerate() {
            let id = system["id"]
                .as_u64()
                .ok_or("invalid_beam_dispatch_system_id")?;
            if !system_ids.insert(id) {
                return Err("duplicate_beam_dispatch_system".into());
            }
            let ids = system["staff_ids"]
                .as_array()
                .filter(|v| !v.is_empty() && v.len() <= 1024)
                .ok_or("invalid_beam_dispatch_members")?;
            for member in ids {
                let sid = member.as_u64().ok_or("invalid_beam_dispatch_staff_id")?;
                if staff_systems.get(&sid) != Some(&id) || !seen_members.insert(sid) {
                    return Err("inconsistent_beam_dispatch_membership".into());
                }
                members.push(sid);
            }
            if system["area"]["x_range"] != json!([0, width])
                || number(&system["area"]["vertical_margin"])? != margin
            {
                return Err("unsupported_beam_dispatch_area".into());
            }
            let coord = system["coordinates"]
                .as_array()
                .filter(|v| v.len() == 5)
                .ok_or("invalid_beam_dispatch_system_coordinates")?;
            let left = integer(&coord[0])?;
            let span = integer(&coord[2])?;
            if span <= 0 {
                return Err("invalid_beam_dispatch_system_span".into());
            }
            // Original getRight() returns left+width, deliberately inclusive here.
            let right = left
                .checked_add(span)
                .ok_or("invalid_beam_dispatch_system_span")?;
            let north_id = if index == 0 {
                Value::Null
            } else {
                raw[index - 1]["staff_ids"]
                    .as_array()
                    .and_then(|v| v.last())
                    .ok_or("invalid_beam_dispatch_neighbor")?
                    .clone()
            };
            let south_id = if index + 1 == raw.len() {
                Value::Null
            } else {
                raw[index + 1]["staff_ids"][0].clone()
            };
            if system["area"]["north_neighbor_last_line"] != north_id
                || system["area"]["south_neighbor_first_line"] != south_id
            {
                return Err("inconsistent_beam_dispatch_neighbor".into());
            }
            let north = if north_id.is_null() {
                None
            } else {
                Some(
                    curves
                        .get(&north_id.as_u64().ok_or("invalid_beam_dispatch_neighbor")?)
                        .ok_or("missing_beam_dispatch_neighbor")?
                        .1
                        .clone(),
                )
            };
            let south = if south_id.is_null() {
                None
            } else {
                Some(
                    curves
                        .get(&south_id.as_u64().ok_or("invalid_beam_dispatch_neighbor")?)
                        .ok_or("missing_beam_dispatch_neighbor")?
                        .0
                        .clone(),
                )
            };
            let area = system_area(width, height, north.as_ref(), south.as_ref(), margin)?;
            systems.push(SystemArea {
                id,
                left,
                right,
                area,
            });
        }
        if order != members {
            return Err("inconsistent_beam_dispatch_staff_order".into());
        }
        let query_work = systems
            .iter()
            .try_fold(0usize, |n, s| n.checked_add(s.area.query_work()))
            .ok_or("unsupported_beam_dispatch_query_work")?;
        Ok(Self {
            systems,
            width,
            height,
            query_work,
        })
    }
    pub fn validate_point_work(&self, count: usize) -> Result<(), String> {
        if count
            .checked_mul(self.query_work)
            .is_none_or(|n| n > MAX_AREA_QUERY_WORK)
        {
            return Err("unsupported_beam_dispatch_query_work".into());
        }
        Ok(())
    }
    /// Original BeamsBuilder.isSideInSystem checks both vertical beam ends.
    /// This uses the full GRID area without staff left/right clipping.
    pub fn is_beam_side_in_system(
        &self,
        id: u64,
        point: [f64; 2],
        height: f64,
    ) -> Result<bool, String> {
        if point.iter().any(|n| !n.is_finite()) || !height.is_finite() || height < 0. {
            return Err("invalid_beam_parallel_system_point".into());
        }
        self.validate_point_work(2)?;
        let system = self
            .systems
            .iter()
            .find(|s| s.id == id)
            .ok_or("missing_beam_parallel_system")?;
        for direction in [-1., 1.] {
            if !system
                .area
                .contains([point[0], point[1] + direction * (height / 2.)])?
            {
                return Ok(false);
            }
        }
        Ok(true)
    }
    pub fn eligible(&self, point: [i32; 2]) -> Result<Vec<u64>, String> {
        let [x, y] = point;
        if x < 0 || y < 0 || x as usize >= self.width || y as usize >= self.height {
            return Ok(Vec::new());
        }
        self.validate_point_work(1)?;
        let mut out = Vec::new();
        for s in &self.systems {
            if x >= s.left && x <= s.right && s.area.contains([x as f64, y as f64])? {
                out.push(s.id);
            }
        }
        Ok(out)
    }
    pub fn register_closed(
        &self,
        registry: &mut Registry,
        g: &GlyphPixels,
    ) -> Result<Option<usize>, String> {
        if self.eligible(centroid(g)?)?.is_empty() {
            Ok(None)
        } else {
            registry.register(g).map(Some)
        }
    }
}
#[derive(Debug, Serialize)]
pub struct SystemSpots {
    pub system_id: u64,
    pub glyph_ids: Vec<usize>,
}
/// Dispatch in extracted-glyph order. Several overlapping system areas can own
/// the same canonical object; freeGlyphs is an insertion-ordered unique set.
pub fn dispatch(
    spots: &[GlyphPixels],
    geometry: &Geometry,
    registry: &mut Registry,
) -> Result<Vec<SystemSpots>, String> {
    let mut systems = geometry
        .systems
        .iter()
        .map(|s| SystemSpots {
            system_id: s.id,
            glyph_ids: Vec::new(),
        })
        .collect::<Vec<_>>();
    dispatch_into(spots, geometry, registry, &mut systems)?;
    Ok(systems)
}
/// Preserve existing free-glyph insertion order (for example VERTICAL_SEED)
/// when a raw beam spot reuses a previously registered canonical object.
pub fn dispatch_into(
    spots: &[GlyphPixels],
    geometry: &Geometry,
    registry: &mut Registry,
    systems: &mut [SystemSpots],
) -> Result<(), String> {
    if spots.len() > MAX_REGISTERED_GLYPHS {
        return Err("unsupported_beam_dispatch_spot_count".into());
    }
    geometry.validate_point_work(spots.len())?;
    let mut runs = 0usize;
    for glyph in spots {
        key(glyph)?;
        runs = runs
            .checked_add(glyph.runs.len())
            .filter(|r| *r <= MAX_REGISTERED_RUNS)
            .ok_or("unsupported_beam_dispatch_run_budget")?;
    }
    if systems.len() != geometry.systems.len() {
        return Err("invalid_beam_dispatch_initial_systems".into());
    }
    let mut seen = Vec::new();
    let mut references = 0usize;
    for (s, g) in systems.iter().zip(&geometry.systems) {
        if s.system_id != g.id {
            return Err("invalid_beam_dispatch_initial_systems".into());
        }
        references = references
            .checked_add(s.glyph_ids.len())
            .filter(|n| *n <= MAX_REGISTERED_GLYPHS)
            .ok_or("unsupported_beam_dispatch_reference_budget")?;
        let mut set = BTreeSet::new();
        for &id in &s.glyph_ids {
            registry.get(id)?;
            if !set.insert(id) {
                return Err("duplicate_beam_dispatch_initial_glyph".into());
            }
        }
        seen.push(set);
    }
    for glyph in spots {
        let ids = geometry.eligible(centroid(glyph)?)?;
        if ids.is_empty() {
            continue;
        }
        let gid = registry.register(glyph)?;
        registry.add_group(gid, Group::BeamSpot)?;
        for id in ids {
            let i = systems.iter().position(|s| s.system_id == id).unwrap();
            if seen[i].insert(gid) {
                references += 1;
                if references > MAX_REGISTERED_GLYPHS {
                    return Err("unsupported_beam_dispatch_reference_budget".into());
                }
                systems[i].glyph_ids.push(gid);
            }
        }
    }
    Ok(())
}
pub fn grouped_snapshot(
    systems: &[SystemSpots],
    registry: &Registry,
    group: Group,
) -> Result<Value, String> {
    let mut rows = Vec::new();
    for system in systems {
        let mut spots = Vec::new();
        for &id in &system.glyph_ids {
            let entry = registry.get(id)?;
            if entry.groups.contains(&group) {
                spots.push(json!({"glyph":glyph_json(&entry.glyph),"groups":entry.groups,"weight":entry.glyph.runs.iter().map(|r|r.length).sum::<usize>(),"centroid":centroid(&entry.glyph)?.map(|v|v as f64)}));
            }
        }
        rows.push(json!({"system_id":system.system_id,"grouped_spots":spots}));
    }
    Ok(json!(rows))
}
/// Original epilog drops only free glyphs whose sole group is BEAM_SPOT.
pub fn remove_exclusive_beam_spots(
    system: &mut SystemSpots,
    registry: &Registry,
) -> Result<(), String> {
    let mut kept = Vec::new();
    for &id in &system.glyph_ids {
        let groups = &registry.get(id)?.groups;
        if groups.len() != 1 || !groups.contains(&Group::BeamSpot) {
            kept.push(id);
        }
    }
    system.glyph_ids = kept;
    Ok(())
}
